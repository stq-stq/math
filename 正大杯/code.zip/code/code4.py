import numpy as np
import skfuzzy as fuzz
import pandas as pd
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
df=pd.read_excel('D:\Desktop\正大杯\标准化.xlsx')
print(df)
# 提取特征数据
X = df.iloc[:,[0,1,2,3,4,5,6,7,8,9,10,11]].values

plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定使用黑体字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 设置聚类数范围
cluster_numbers = range(2, 10)
silhouette_scores = []

# 计算不同聚类数下的轮廓系数
for n_clusters in cluster_numbers:
    cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
        X.T, n_clusters, 2, error=0.005, maxiter=1000, init=None)
    labels = np.argmax(u, axis=0)
    score = silhouette_score(X, labels)
    silhouette_scores.append(score)

# 找到具有最高轮廓系数的聚类数
best_n_clusters = cluster_numbers[np.argmax(silhouette_scores)]
print(f'最优聚类数: {best_n_clusters}')
print(silhouette_scores)
# 使用最优聚类数进行模糊C均值聚类
cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
    X.T, best_n_clusters, 2, error=0.005, maxiter=1000, init=None)
cluster_membership = np.argmax(u, axis=0)

# 设置图片清晰度
plt.rcParams['figure.dpi'] = 300


# 可视化轮廓系数
plt.figure(figsize=(10, 6))
plt.plot(cluster_numbers, silhouette_scores, marker='o')
plt.xlabel('聚类数')
plt.ylabel('轮廓系数')
plt.title('不同聚类数对应的轮廓系数')
plt.grid(True)
plt.xticks(cluster_numbers)
plt.show()
# 可视化聚类结果（这里以数据前两列特征为例）
plt.scatter(X[:, 0], X[:, 1], c=cluster_membership, cmap='viridis', s=50, alpha=0.7)
plt.scatter(cntr[:, 0], cntr[:, 1], marker='x', s=200, c='red')
plt.xlabel(df.columns[0])
plt.xticks(rotation=45)
plt.ylabel(df.columns[1])
plt.title(f'模糊C均值聚类结果 (聚类数: {best_n_clusters})')
plt.show()