import numpy as np
import matplotlib.pyplot as plt
# 设置字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定使用黑体字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
# 数据
categories = ['年龄', '受教育程度', '日工作时间', '加班工作薪酬支付情况', '劳动合同情况', '工伤保险情况', '医疗保险情况', '养老保险情况', '激励机制', '成就感获得', '环境和机会']
data1 = [-0.20, -0.25, 0.54, 0.70, 0.85, 1.08, 0.96, 0.99, 0.86, 0.95, 0.96]
data2 = [0.07, 0.09, -0.18, -0.24, -0.29, -0.36, -0.32, -0.33, -0.29, -0.32, -0.32]

# 角度设置
angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
angles += angles[:1]  # 使雷达图封闭

# 初始化图形
fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))

# 绘制聚类1的数据
data1_plot = np.append(data1, data1[0])
ax.plot(angles, data1_plot, label='聚类1', linewidth=2)
ax.fill(angles, data1_plot, alpha=0.25)

# 在聚类1区域添加类别标签
center_angle = np.mean(angles)
ax.text(center_angle, np.mean(data1_plot), '聚类1', ha='center', va='center', fontsize=12, fontweight='bold')

# 绘制聚类2的数据
data2_plot = np.append(data2, data2[0])
ax.plot(angles, data2_plot, label='聚类2', linewidth=2)
ax.fill(angles, data2_plot, alpha=0.25)

# 在聚类2区域添加类别标签
ax.text(center_angle, np.mean(data2_plot), '聚类2', ha='center', va='center', fontsize=12, fontweight='bold')

# 设置标签和标题
ax.set_xticks(angles[:-1])
ax.set_xticklabels(categories)

# 设置网格线
ax.grid(True)

# 添加图例
ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))

# 根据数据范围设置极径范围
min_val = min(min(data1), min(data2))
max_val = max(max(data1), max(data2))
ax.set_rlim(min_val - 0.5, max_val + 0.5)

# 显示图形
plt.show()