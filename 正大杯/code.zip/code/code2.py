import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

from sklearn.metrics import calinski_harabasz_score
# df=pd.read_excel('D:\Desktop\正大杯\kmeans.xlsx')
df=pd.read_excel('D:\Desktop\正大杯\标准化.xlsx')
# 设置字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定使用黑体字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
print(df)
X = df.iloc[:,[0,1,2,3,4,5,6,7,8,9,10,11]].values
# 对类别型数据进行独热编码
# X = pd.get_dummies(x)

# 定义要尝试的聚类数范围
cluster_range = range(2, 11)
silhouette_scores = []

# 遍历不同的聚类数
for n_clusters in cluster_range:
    # 使用KMeans进行聚类
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    kmeans.fit(X)
    labels = kmeans.labels_
    # 计算轮廓系数
    silhouette_avg = silhouette_score(X, labels)
    silhouette_scores.append(silhouette_avg)

# 找到轮廓系数最大时的聚类数
best_n_clusters = cluster_range[np.argmax(silhouette_scores)]
print(f"最佳聚类数: {best_n_clusters}")

# 绘制轮廓系数随聚类数变化的曲线
plt.plot(cluster_range, silhouette_scores, marker='o')
plt.xlabel('聚类数')
plt.ylabel('轮廓系数')
plt.title('轮廓系数随聚类数变化')
plt.show()