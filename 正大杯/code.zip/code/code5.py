import pandas as pd
from factor_analyzer import ConfirmatoryFactorAnalyzer, ModelSpecificationParser

# 假设你已经有了包含17个量表题目的数据，这里简单模拟
data = pd.read_excel('D:\\Desktop\\正大杯\\satisfaction.xlsx')

# 定义四个维度和对应的题目
dimension_indexes = {
    'dimension1': [0, 1, 2,3, 4],
    'dimension2': [5,6, 7,8,9],
    'dimension3': [10, 11, 12, 13,14],
    'dimension4': [15, 16]
}

# 根据索引获取每个维度对应的题目名称
dimensions = {}
for dimension, indexes in dimension_indexes.items():
    dimensions[dimension] = data.columns[indexes].tolist()

# 构建模型规格
model_spec = ModelSpecificationParser.parse_model_specification_from_dict(data, dimensions)

# 创建验证性因子分析对象
cfa = ConfirmatoryFactorAnalyzer(model_spec, disp=False)

# 拟合数据
cfa.fit(data)

# 查看因子载荷
loadings = cfa.loadings_
print("因子载荷:")
print(loadings)

# 查看因子协方差矩阵
factor_cov = cfa.factor_varcovs_
print("因子协方差矩阵:")
print(factor_cov)