import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

# 读取数据，假设数据文件名为 'your_data.csv'
data = pd.read_excel('D:\Desktop\正大杯\data.xlsx')

# 数据标准化
scaler = StandardScaler()
scaled_data = scaler.fit_transform(data)

# 执行DBSCAN聚类
dbscan = DBSCAN(eps=0.3, min_samples=5)
labels = dbscan.fit_predict(scaled_data)

# 将聚类标签添加到原始数据中
data['Cluster'] = labels
print(data)
# 将结果保存为CSV文件
# data.to_csv('clustered_data.csv', index=False)