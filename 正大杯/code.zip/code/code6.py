import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 假设你已经有了一个包含11个特征的数据集，这里简单生成一个示例数据
df=pd.read_excel('D:\Desktop\正大杯\标准化.xlsx')
data = df.iloc[:,[0,1,2,3,4,5,6,7,8,9,10]].values

# 进行K-means聚类
n_clusters = 2
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
cluster_labels = kmeans.fit_predict(data)
new_cluster_labels = cluster_labels + 1

# 使用t-SNE将数据从11维降到3维
tsne = TSNE(n_components=3, random_state=42)
data_3d = tsne.fit_transform(data)

# 创建一个三维图形
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# 可视化降维后的数据点，根据聚类标签进行颜色区分
scatter = ax.scatter(data_3d[:, 0], data_3d[:, 1], data_3d[:, 2], c=new_cluster_labels, cmap='viridis')

# 添加颜色条
legend = ax.legend(*scatter.legend_elements(), title="Clusters")
ax.add_artist(legend)

# 设置坐标轴标签和标题
ax.set_xlabel('t-SNE 1')
ax.set_ylabel('t-SNE 2')
ax.set_zlabel('t-SNE 3')
plt.title('K-means Clustering Results Visualized with t-SNE (3D)')

plt.show()