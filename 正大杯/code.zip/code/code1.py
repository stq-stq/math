import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pandas import read_excel
from sklearn.cluster import KMeans
from sklearn.metrics import calinski_harabasz_score
# df=pd.read_excel('D:\Desktop\正大杯\kmeans.xlsx')
# df=pd.read_excel('D:\Desktop\正大杯\data.xlsx')
df=pd.read_excel('D:\Desktop\正大杯\标准化.xlsx')
print(df)

# 设置字体

plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定使用黑体字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 数据标准化


# 提取前六列数据
X = df.iloc[:,[0,1,2,3,4,5,6,7,8,9,10,11]].values
print(X)
# 定义要尝试的聚类数范围
cluster_range = range(2, 11)
ch_scores = []

# 遍历不同的聚类数
for n_clusters in cluster_range:
    # 使用KMeans进行聚类
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    kmeans.fit(X)
    labels = kmeans.labels_

    # 计算Calinski-Harabasz指标
    ch_score = calinski_harabasz_score(X, labels)
    ch_scores.append(ch_score)

# 找到Calinski-Harabasz指标最大时的聚类数
best_n_clusters = cluster_range[np.argmax(ch_scores)]
print(f"最佳聚类数: {best_n_clusters}")

# 绘制Calinski-Harabasz指标随聚类数变化的曲线
plt.plot(cluster_range, ch_scores, marker='o')
plt.xlabel('聚类数')
plt.ylabel('Calinski-Harabasz指标')
plt.title('Calinski-Harabasz指标随聚类数变化')
plt.show()